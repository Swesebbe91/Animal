package com.company;

public class Message {
}
