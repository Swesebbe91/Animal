package com.company;

public class Coordinates {


}
