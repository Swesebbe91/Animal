package com.company;

public enum Direction {
    LEFT, RIGHT, UP, DOWN
}
