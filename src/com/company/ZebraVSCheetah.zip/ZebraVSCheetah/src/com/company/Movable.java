package com.company;

public interface Movable {

    void moveAnimalRight();
    void moveAnimalLeft();
    void moveAnimalUp();
    void moveAnimalDown();
    void move();
    void eat();
    void dead();


}
