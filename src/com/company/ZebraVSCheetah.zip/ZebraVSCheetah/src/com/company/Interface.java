package com.company;

public interface Interface {

    void move();
    void eat();
    void rest();
    void dead();

}
